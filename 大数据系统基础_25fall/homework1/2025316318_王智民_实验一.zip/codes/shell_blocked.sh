#!/bin/bash
awk '$1~"^chapter"{}' wc_dataset.txt
awk '$1~"^chapter"{}' wc_dataset.txt
awk '$1~"^chapter"{}' wc_dataset.txt
awk '$1~"^chapter"{}' wc_dataset.txt
awk '$1~"^chapter"{}' wc_dataset.txt
